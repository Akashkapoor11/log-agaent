import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  base: '/milan-aegis-fe/',
  server: {
    proxy: {
      '/milan-aegis/api': {
        target: 'http://localhost:5000',
        changeOrigin: true,
      }
    }
  }
})
